using Unity.Netcode;
using Unity.Netcode.Components;
using UnityEngine;
using DilmerGames.Core.Singletons;

public class LiveTree : NetworkSingleton<LiveTree>
{
    [SerializeField]
    private float networkPlayerHealthInspector = 500;

    [SerializeField]
    public NetworkVariable<float> networkPlayerHealth;

    [SerializeField]
    private GameObject treePlaceholderPrefab;

    private GameObject currentPlaceholder;

    // [Header("List of Prefabs")]
    // public List<GameObject> prefabs = new List<GameObject>();


    private Vector3 transformPlayer;

    private Rigidbody rb;

    private NetworkObjectPool objectPool;
    private Puntaje puntaje;

    private void Awake()
    {
        networkPlayerHealth = new NetworkVariable<float>(networkPlayerHealthInspector);
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true; // Desactivar la física al inicio.
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            RaycastHit CheckTree;
            if (Physics.Raycast(this.gameObject.transform.position, this.gameObject.transform.forward, out CheckTree, 5))
            {
                if (CheckTree.collider.gameObject == currentPlaceholder)
                {
                    PlantTreeAtPlaceholderServerRpc(CheckTree.point,CheckTree.collider.gameObject.GetComponent<NetworkObject>().NetworkObjectId);
                }
            } 
        }
    }


    public void CheckTreeHealth(Vector3 transformPlayerParam)
    {
        if(networkPlayerHealth.Value <= 0)
        {   
            transformPlayerParam = transformPlayer;
            FallTreeServerRpc();
        }
    }


    [ServerRpc(RequireOwnership = false)]
    private void FallTreeServerRpc()
    {
        // Activar la física.
        rb.isKinematic = false;
        rb.AddForce(transformPlayer * 10f); // Agregar una pequeña fuerza hacia atrás para iniciar la caída.
        Invoke("CreateTreePlaceholder",1f);//Cuando el árbol cae, crea un marcador
        Invoke("CallReturnNetworkClientRpc",10f);
    }


    private void CreateTreePlaceholder()
    {
        currentPlaceholder = Instantiate(treePlaceholderPrefab, transformPlayer, Quaternion.identity);
        currentPlaceholder.SetActive(true);
    }



    [ClientRpc]
    private void CallReturnNetworkClientRpc()
    {   
        puntaje = Puntaje.Instance;
        puntaje.wood.Value += 10;
        objectPool = NetworkObjectPool.Instance;
        objectPool.ReturnNetworkObject(this.NetworkObject, this.gameObject);
    }



    [ServerRpc(RequireOwnership = false)]
    private void PlantTreeAtPlaceholderServerRpc(Vector3 position,ulong treePrefab)
    {

        // Solicitar un objeto de la piscina
        var spawnerControl = SpawnerControl.Instance;
        spawnerControl.SpawnTreeCall(position, Quaternion.identity);

        // Si tu versión de Netcode requiere que llames a Spawn después de sacar un objeto de la piscina, hazlo aquí.
        // if(!treePrefab.IsSpawned)
        // {
        //     networkTree.Spawn();
        // }

        // Eliminar el marcador actual
        Destroy(currentPlaceholder);
        currentPlaceholder = null;
    }
}
