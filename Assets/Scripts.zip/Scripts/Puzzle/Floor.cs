using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

public class Floor : NetworkBehaviour
{
    private bool isWalking = true;
    [SerializeField] 
    private bool WinCondition = false;

}